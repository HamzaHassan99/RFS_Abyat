
from tkinter import *
from PIL import Image, ImageTk
import  time
import arabic_reshaper
from bidi.algorithm import get_display
import  urllib.request
from io import BytesIO
import continuous_threading
# from getmac import get_mac_address
from ttkbootstrap import Style
from connectionpage import scanqr
import requests
import re ,uuid
import qrcode

from subprocess import run

#import pyqrcode
# Change threading._shutdown() to automatically call Thread.allow_shutdown()
continuous_threading.set_allow_shutdown(True)
continuous_threading.set_shutdown_timeout(0)  # Default 1


def checkinit(mycanvas1 ,i ,root):
    var =0


    main_api = "https://rfs.abyat.com/api/station/init"

    mac = (':'.join(['{:02x}'.format((uuid.getnode() >> ele) & 0xff)
                      for ele in range(0, 8 * 6, 8)][::-1]))


    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    print(mac)



    data = {'device id': mac}
    while i== 0:

        try:

            json_data = requests.post(url=main_api, data=data).json()


            if json_data['isActive'] == True and i == 0:
                run("vcgencmd display_power 1", shell=True)
                banr = json_data['data']['banner']

                qrdata = json_data['data']['qr_link']
                stname = json_data['data']['name']
                stname_ar1 = json_data['data']['name_ar']
                stname_ar2=arabic_reshaper.reshape(stname_ar1)
                stname_ar=get_display(stname_ar2)

                text1 = "Welcome to ABYAT"

                global qr, photo
                qr = qrcode.QRCode(
                    version=11,

                    box_size=4,
                    border=6,
                )
                #qr = pyqrcode.create(qrdata)
                #photo = BitmapImage(data=qr.xbm(scale=3), background="white")
                qr.add_data(qrdata)
                qr.make(fit=True, )
                img = qr.make_image(fill='Black', back_color='White')

                img.save('qrcode.png')
                photo = ImageTk.PhotoImage(file="qrcode.png")


                u = urllib.request.urlopen(banr)
                raw_data = u.read()
                u.close()
                im = Image.open(BytesIO(raw_data))
                im =im.resize((screen_width, screen_height), Image.ANTIALIAS)

                #im = im.resize((768, 667))
                global tkimage, logo
                tkimage = ImageTk.PhotoImage(im)
                logo = PhotoImage(file="Abyatlogo.png")
                #ar_text = PhotoImage(file="help.png")

                mycanvas1.delete("background")
                mycanvas1.delete("logo")
                mycanvas1.delete("stat")
                mycanvas1.delete("all")
                helptext1="لطلب المساعدة"
                helptext2 = arabic_reshaper.reshape(helptext1)
                helptext = get_display(helptext2)

                mycanvas1.create_image(screen_width/2,screen_height/2,image=tkimage, tag="storeimg")
                mycanvas1.create_text(mycanvas1.winfo_screenwidth()/2,mycanvas1.winfo_screenheight()/4, text=text1,anchor="center", font=("HelveticaNeueLT Arabic 45 Light", 26, 'bold'), fill="#fff", tag="wtext")
                mycanvas1.create_image(mycanvas1.winfo_screenwidth()/2, mycanvas1.winfo_screenheight()/6, image=logo, anchor="center", tag="logoimg")
                mycanvas1.create_image(mycanvas1.winfo_screenwidth()/2,mycanvas1.winfo_screenheight()/1.8, image=photo, anchor="center", tag="qrcode")
                #mycanvas1.create_image(mycanvas1.winfo_screenwidth()/2.3,mycanvas1.winfo_screenheight()/1.2, image=ar_text, anchor="nw", tag="help_ar")
                mycanvas1.create_text(mycanvas1.winfo_screenwidth() / 2, mycanvas1.winfo_screenheight() /1.25,
                                      text="For Help",anchor="center", font=("HelveticaNeueLT Arabic 45 Light", 22, 'bold'), fill="#fff", tag="help_ar")
                mycanvas1.create_text(mycanvas1.winfo_screenwidth()/2,mycanvas1.winfo_screenheight()/1.2, text=helptext,anchor="center", font=("HelveticaNeueLT Arabic 45 Light",26, 'bold'), fill="#fff", tag="help_ar")
                i = 1


                mycanvas1.create_text(mycanvas1.winfo_screenwidth()/2,mycanvas1.winfo_screenheight()/3.1, text=stname,anchor="center", font=("HelveticaNeueLT Arabic 45 Light", 26, 'bold'), fill="#fff", tag="sname")
                mycanvas1.create_text(mycanvas1.winfo_screenwidth()/2,mycanvas1.winfo_screenheight()/2.7, text=stname_ar,anchor="center", font=("HelveticaNeueLT Arabic 45 Light", 26, 'bold'), fill="#fff",
                                      tag="sname_ar")
                scanqr(json_data, mycanvas1, mac, 0, 0, root)
            else:
                run("vcgencmd display_power 0", shell=True)







        except:

            mycanvas1.delete("sname")
            mycanvas1.delete("sname_ar")
            # mycanvas1.delete("help")
            mycanvas1.delete("help_ar")
            mycanvas1.delete("qrcode")
            mycanvas1.delete("status")
            #run("vcgencmd display_power 0", shell=True)
            mycanvas1.create_text(mycanvas1.winfo_screenwidth()/2,mycanvas1.winfo_screenheight()/2, text="No Service",anchor="center", font=("HelveticaNeueLT Arabic 45 Light", 26, 'bold'),
                                  fill="white",
                                  tag="status")
            time.sleep(5)
            checkinit(mycanvas1, 0, root)

            i = 0