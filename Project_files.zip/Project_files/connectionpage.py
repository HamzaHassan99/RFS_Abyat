import os,signal
from tkinter import *
from tkinter import ttk
from PIL import Image, ImageTk
import time
import arabic_reshaper
from bidi.algorithm import get_display



import urllib.request
from io import BytesIO
import continuous_threading
import requests
from subprocess import run
# Change threading._shutdown() to automatically call Thread.allow_shutdown()
continuous_threading.set_allow_shutdown(True)
continuous_threading.set_shutdown_timeout(0)  # Default 1
val = 0


global myprogressbar



def call_salesmen(json_data5,mac,mycanvas4):
    salemen_url = "https://rfs.abyat.com/api/station/salesman"
    parm = {"device_id": mac, "salesmen_id": json_data5["salesmen_id"]}
    json_data44 = requests.post(url=salemen_url, data=parm).json()

    salesman_img = json_data44['data']['image']

    salesman_name1 = json_data44['data']['name']
    salesman_name2 = arabic_reshaper.reshape(salesman_name1)
    salesman_name = get_display(salesman_name2)

    u = urllib.request.urlopen(salesman_img)
    raw_data = u.read()
    u.close()
    im = Image.open(BytesIO(raw_data))

    im = im.resize((200, 200))
    # mycanvas4.delete("storeimg")
    #single1 = PhotoImage(file="2xsingle.png")
    helptx ="بالطريق لخدمتكم"
    helptx1 = arabic_reshaper.reshape(helptx)
    single1 = get_display(helptx1)
    mycanvas4.delete("en_t")
    mycanvas4.delete("ar_t")
    mycanvas4.delete("en_text")
    mycanvas4.delete("ar_text")
    mycanvas4.delete("logoimg")
    mycanvas4.delete("status1")
    mycanvas4.delete("status")
    tkimage1 = ImageTk.PhotoImage(im)



    mycanvas4.create_image(mycanvas4.winfo_screenwidth() / 2, mycanvas4.winfo_screenheight() / 2.4, image=tkimage1,
                           anchor="center", tag="sale_img")

    mycanvas4.create_text(mycanvas4.winfo_screenwidth() / 2, mycanvas4.winfo_screenheight() / 1.9,
                          text=salesman_name,anchor="center", font=("HelveticaNeueLT Arabic 45 Light", 26,'bold'), fill="#fff",
                          tag="sale_name")
    mycanvas4.create_text(mycanvas4.winfo_screenwidth() / 2, mycanvas4.winfo_screenheight() / 1.7,
                          text=single1, anchor="center", font=("HelveticaNeueLT Arabic 45 Light", 26,'bold'), fill="#fff",
                          tag="sale_ar")

    #mycanvas4.create_image(mycanvas4.winfo_screenwidth() / 2, mycanvas4.winfo_screenheight() / 1.2, image=single1,
    #                       anchor="center", tag="sale_ar")
    time.sleep(10)
    mycanvas4.delete("sale_name")
    mycanvas4.delete("sale_ar")



    i = 1



def checknxtreq(json_data2, stid, mycanvas4, i, j, mac, root, progressbr1, loopcount,nextperson,requestmadeid):
    try:
        count1 = 0
        status = 0
        a=1


        
        if j==1:
            while count1<4:
                time.sleep(5)
                res=checkreq(json_data2,stid,0,mycanvas4,mac,root,progressbr1,requestmadeid)
                if res==0:
                    status=1
                    count1=4
                if res==2:
                    count1=4
                else:
                    count1=count1+1

        if status==1:
            return 0



        reqnext = "https://rfs.abyat.com/api/request/next"
        datanxt = {"device_id": mac, "station_id": stid,
                   "requestId": json_data2["requestId"], "requestMadeId": requestmadeid,
                   "nextPerson": nextperson, "loopCount": loopcount,
                   }
        # saleid = int(json_data4["salesmen_id"])

        


        json_data3 = requests.post(url=reqnext, data=datanxt).json()
        time.sleep(2)

        saleid = int(json_data3["salesmen_id"])






        if json_data3['requestAccepted'] == True and saleid>int(0) :

            mycanvas4.delete("wtext")
            call_salesmen(json_data3,mac,mycanvas4)
            progressbr1.destroy()


            return 0

        if json_data3["requestMade"] == False and json_data3['pendingRequestFound'] == False and json_data3[
                 'requestAccepted'] == False:
            mycanvas4.delete("en_text")
            mycanvas4.delete("ar_text")
            mycanvas4.delete("ar_t")
            mycanvas4.delete("en_t")
            mycanvas4.delete("status1")
            mycanvas4.delete("status")

            #txt_sorry = PhotoImage(file="2xsorry.png")
            text_str = """Sorry, Our sales staff are busy with other customers,
                     they will be with you shortly"""
            text_arb1 = "عذراً، جميع موظفينا مشغولين حالي،"
            text_arb3=  "سوف يأتي أحدهم لخدمتكم بمجرد الإنتهاء من خدمة العميل الآخر"
            text_arb3 = arabic_reshaper.reshape(text_arb3)
            text_arb4 = get_display(text_arb3)



            text_arb2 = arabic_reshaper.reshape(text_arb1)
            text_arb = get_display(text_arb2)
            if mycanvas4.winfo_screenwidth()<=480:
                sizen=15
                sizar=15
            if mycanvas4.winfo_screenwidth()>=481 and mycanvas4.winfo_screenwidth()<=767:

                sizen=17
                sizar=17
            if mycanvas4.winfo_screenwidth() >= 768 and mycanvas4.winfo_screenwidth() <=1024:

                sizen = 19
                sizar = 19
            if mycanvas4.winfo_screenwidth() >= 1025 and mycanvas4.winfo_screenwidth() <= 1280:

                sizen = 20
                sizar = 20
            if mycanvas4.winfo_screenwidth() >= 1281:

                sizen = 22
                sizar = 22
            mycanvas4.create_text(mycanvas4.winfo_screenwidth() / 2, mycanvas4.winfo_screenheight() / 2,
                                  text=text_str, anchor="center", font=("HelveticaNeueLT Arabic 45 Light", sizen, 'bold'), fill="#fff",
                                  tag="ar_t")
            mycanvas4.create_text(mycanvas4.winfo_screenwidth() / 2, mycanvas4.winfo_screenheight() / 1.8,
                                  text=text_arb,anchor="center", font=("HelveticaNeueLT Arabic 45 Light", sizar, 'bold'), fill="#fff",
                                  tag="ar_t")
            mycanvas4.create_text(mycanvas4.winfo_screenwidth() / 2, mycanvas4.winfo_screenheight() / 1.7,
                                  text=text_arb4, anchor="center", font=("HelveticaNeueLT Arabic 45 Light", sizar, 'bold'),
                                  fill="#fff",
                                  tag="ar_t")
            #mycanvas4.create_image(mycanvas4.winfo_screenwidth()/2,mycanvas4.winfo_screenheight()/2, image=txt_sorry, anchor="center", tag="ar_t")

                    #
           # myprogressbar2 = ttk.Progressbar(root, orient=HORIZONTAL, length=400, mode="determinate")
           # myprogressbar2.start(40)
           # myprogressbar2.place(x=100, y=380)


            time.sleep(5)
            progressbr1.destroy()


            i = 1
            return 0
                ##############################
            ##############################
        if json_data3["requestMade"] == True and json_data3['pendingRequestFound'] == False and json_data3[
            'requestAccepted'] == False:
            loopcount = json_data3['loopCount']
            nextperson = json_data3['nextPerson']
            requestmadeid = json_data3["requestMadeId"]


            c = checknxtreq(json_data2, stid, mycanvas4, 0, 1, mac, root, progressbr1, loopcount, nextperson,
                            requestmadeid)

            return 0









    except:
        progressbr1.destroy()
        mycanvas4.delete("en_t")
        mycanvas4.delete("ar_t")
        mycanvas4.delete("en_text")
        mycanvas4.delete("ar_text")
        mycanvas4.delete("sale_img")
        mycanvas4.delete("sale_name")
        mycanvas4.delete("sale_ar")
        from page1 import checkinit
        checkinit(mycanvas4, 0, root)

        # mycanvas4.create_text(350, 400, text="Status: Not Connected", font=("Helvetica", 24, 'bold'),
        #                      fill="white",
        #                     tag="status1")


        i = 0



def checkreq(json_data2, stid, i, mycanvas4, mac, root, progressbr,reqstmadeid):
    # ):
   # thrednxtreq = continuous_threading.PausableThread(target=checknxtreq, name="Thread2",
    #                                                  args=(json_data2, stid, mycanvas4, 0, 0, mac, True, root))
   #                                                  args=(json_data2, stid, mycanvas4, 0, 0, mac, True, root))
   var = 0

   time_check = 0
   while i == 0:

       try:

           check_req_url = "https://rfs.abyat.com/api/request/check"
           param = {"device_id": mac, "station_id": stid, "requestId": json_data2["requestId"],
                    "requestMadeId": reqstmadeid}
           json_data4 = requests.post(url=check_req_url, data=param).json()



           saleid = int(json_data4["salesmen_id"])

           if json_data4["status"] == True and json_data4["requestAccepted"] == True:
                salemen_url = "https://rfs.abyat.com/api/station/salesman"
                parm = {"device_id": mac, "salesmen_id": json_data4["salesmen_id"]}
                json_data4 = requests.post(url=salemen_url, data=parm).json()

                mycanvas4.delete("wtext")


                salesman_img = json_data4['data']['image']

                salesman_name1 = json_data4['data']['name']
                #single = PhotoImage(file="2xsingle.png")
                salesman_name2 = arabic_reshaper.reshape(salesman_name1)
                salesman_name = get_display(salesman_name2)
                helptx_1 = "بالطريق لخدمتكم"
                helptx_2 = arabic_reshaper.reshape(helptx_1)
                single = get_display(helptx_2)

                u = urllib.request.urlopen(salesman_img)
                raw_data = u.read()
                u.close()
                im1 = Image.open(BytesIO(raw_data))

                im1 = im1.resize((200, 200))


                mycanvas4.delete("en_t")
                mycanvas4.delete("ar_t")
                mycanvas4.delete("en_text")
                mycanvas4.delete("ar_text")
                mycanvas4.delete("logoimg")
                progressbr.destroy()
                mycanvas4.delete("status1")
                mycanvas4.delete("status")
                tkimage1 = ImageTk.PhotoImage(im1)

                mycanvas4.create_image(mycanvas4.winfo_screenwidth()/2,mycanvas4.winfo_screenheight()/2.4, image=tkimage1, anchor="center", tag="sale_img")

                mycanvas4.create_text(mycanvas4.winfo_screenwidth()/2,mycanvas4.winfo_screenheight()/1.9,text=salesman_name,anchor="center", font=("HelveticaNeueLT Arabic 45 Light", 26,'bold'), fill="#fff",
                                      tag="sale_name")
                mycanvas4.create_text(mycanvas4.winfo_screenwidth() / 2, mycanvas4.winfo_screenheight() / 1.7,
                                      text=single, anchor="center", font=("HelveticaNeueLT Arabic 45 Light", 26,'bold'), fill="#fff",
                                      tag="sale_ar")
                #mycanvas4.create_image(mycanvas4.winfo_screenwidth()/2,mycanvas4.winfo_screenheight()/1.2, image=single, anchor="center", tag="sale_ar")
                time.sleep(10)
                progressbr.destroy()
                mycanvas4.delete("sale_name")
                mycanvas4.delete("sale_ar")


                i = 1
                var = 1
                return 0
           if  json_data4["status"] ==True and json_data4["requestAccepted"] == False:
                return 2






       except:
            mycanvas4.delete("en_t")
            mycanvas4.delete("ar_t")

            mycanvas4.delete("en_text")
            mycanvas4.delete("ar_text")
            mycanvas4.delete("sale_img")
            mycanvas4.delete("sale_name")
            mycanvas4.delete("sale_ar")

            i = 0
            mycanvas4.create_text(mycanvas4.winfo_screenwidth()/2,mycanvas4.winfo_screenheight()/2, text="No Service",anchor="center", font=("HelveticaNeueLT Arabic 45 Light", 26, 'bold'),
                                  fill="white",
                                  tag="status")
            return 0
       return 1





def scanqr(jsondata, mycanvas2, mac, j, i, root):
    tmcount = 0

    #s = ttk.Style()
    #s.theme_use("classic")
    #s.configure("green.Horizontal.Tprogressbar", foreground="green", background="green")
    myprogressbar = ttk.Progressbar(root,style="green.Horizontal.TProgressbar",orient=HORIZONTAL, length=root.winfo_screenwidth(), mode="determinate")

    init_api = "https://rfs.abyat.com/api/station/init"
    data = {'device id': mac}


    screen = 0


    while i == 0:
        on_off_check = requests.post(url=init_api, data=data).json()
        if on_off_check['shutdown']==True:
            os.system("sudo shutdown -h now")
        if on_off_check['restart']==True:

            os.system('reboot')
        if on_off_check['isActive'] == True:
            if screen==0:
                run("vcgencmd display_power 1", shell=True)
                screen=screen+1





            qrapi = "https://rfs.abyat.com/api/station/checkQr"
            data = {'device_id': mac, "station": jsondata['data']['station']}

            try:

                json_data1 = requests.post(url=qrapi, data=data).json()


                if json_data1['status'] == True:

                    stid = jsondata['data']['station']

                    reqinit = "https://rfs.abyat.com/api/request/init"
                    data1 = {'device_id': mac, "station_id": stid}
                    mycanvas2.delete("qrcode")
                    mycanvas2.delete("scanbutton")

                    mycanvas2.delete("wtext")
                    mycanvas2.delete("en_t")
                    mycanvas2.delete("ar_t")
                    mycanvas2.delete("status")
                    mycanvas2.delete("sname")
                    mycanvas2.delete("sname_ar")
                    mycanvas2.delete("help_ar")

                    wait_txt="يرجى الانتظار .. سيقوم احد من فريق ابيات بمساعدتك"
                    wait_txt2 = arabic_reshaper.reshape(wait_txt)
                    wait_img = get_display(wait_txt2)
                    w1="Please wait.. ABYAT team will be with you shortly"

                    #wait_img = PhotoImage(file="2xwait.png")
                    if mycanvas2.winfo_screenwidth() <= 480:
                        sizen = 15
                        sizar = 15
                    if mycanvas2.winfo_screenwidth() >= 481 and mycanvas2.winfo_screenwidth() <= 767:
                        sizen = 17
                        sizar = 17
                    if mycanvas2.winfo_screenwidth() >= 768 and mycanvas2.winfo_screenwidth() <= 1024:
                        sizen = 18
                        sizar = 18
                    if mycanvas2.winfo_screenwidth() >= 1025 and mycanvas2.winfo_screenwidth() <= 1280:
                        sizen = 20
                        sizar = 20
                    if mycanvas2.winfo_screenwidth() >= 1281:
                        sizen = 22
                        sizar = 22
                    mycanvas2.create_text(mycanvas2.winfo_screenwidth() / 2, mycanvas2.winfo_screenheight() / 2,
                                          text=w1, anchor="center", font=("HelveticaNeueLT Arabic 45 Light", sizen, 'bold'), fill="#fff",
                                          tag="ar_text")
                    mycanvas2.create_text(mycanvas2.winfo_screenwidth()/2,mycanvas2.winfo_screenheight()/1.9, text=wait_img,anchor="center", font=("HelveticaNeueLT Arabic 45 Light", sizar, 'bold'), fill="#fff", tag="ar_text")
                    myprogressbar.start(40)
                    myprogressbar.place(x=mycanvas2.winfo_screenwidth()/mycanvas2.winfo_screenwidth(), y=mycanvas2.winfo_screenheight()/1.01)
                    time.sleep(5)

                    json_data2 = requests.post(url=reqinit, data=data1).json()


                    a = 1
                    if json_data2['requestMade'] == True and json_data2["status"] == True:

                        mycanvas2.delete("wxtext")
                        requestmadeid = json_data2["requestMadeId"]

                        count = 0
                        while a != 0:
                            a = checkreq(json_data2, stid, 0, mycanvas2, mac, root, myprogressbar, requestmadeid)
                            if a == 0:
                                break
                            if a == 2:
                                count = 4
                            else:
                                time.sleep(5)
                                count = count + 1
                            if a != 0 and count == 4:
                                a = checknxtreq(json_data2, stid, mycanvas2, 0, 0, mac, root, myprogressbar,
                                                json_data2['loopCount'], json_data2['nextPerson'],
                                                json_data2['requestMadeId'])
                                count = 0

                        ############








                        ##############################

                        j = 0
                        i = 1

                    # thred=continuous_threading.PausableThread(target=checknxtreq, name='thread1',args=(json_data2,data,0,mycanvas2))
                    # thred.start()

                    if json_data2['requestMade'] == False and json_data2["status"] == True:
                        mycanvas2.delete("qrcode")
                        mycanvas2.delete("scanbutton")
                        mycanvas2.delete("wtext")

                        mycanvas2.delete("en_t")
                        mycanvas2.delete("ar_text")
                        mycanvas2.delete("status")
                        mycanvas2.delete("sname")
                        mycanvas2.delete("sname_ar")
                        mycanvas2.delete("help")
                        mycanvas2.delete("help_ar")

                        #sorry_text = PhotoImage(file="2xsorry.png")

                        #mycanvas2.create_image(mycanvas2.winfo_screenwidth()/2,mycanvas2.winfo_screenheight()/2, image=sorry_text, anchor="center", tag="ar_t")
                        text_str ="""Sorry, Our sales staff are busy with other customers,
                        they will be with you shortly"""
                        text_arb1 = "عذراً، جميع موظفينا مشغولين حالي،"
                        text_arb3 = "سوف يأتي أحدهم لخدمتكم بمجرد الإنتهاء من خدمة العميل الآخر"
                        text_arb3 = arabic_reshaper.reshape(text_arb3)
                        text_arb4 = get_display(text_arb3)

                        text_arb2 = arabic_reshaper.reshape(text_arb1)
                        text_arb = get_display(text_arb2)


                        mycanvas2.create_text(mycanvas2.winfo_screenwidth() / 2, mycanvas2.winfo_screenheight() / 2,
                                              text=text_str, anchor="center",
                                              font=("HelveticaNeueLT Arabic 45 Light", sizen, 'bold'), fill="#fff",
                                              tag="ar_t")
                        mycanvas2.create_text(mycanvas2.winfo_screenwidth() / 2, mycanvas2.winfo_screenheight() / 1.8,
                                              text=text_arb, anchor="center",
                                              font=("HelveticaNeueLT Arabic 45 Light", sizar, 'bold'), fill="#fff",
                                              tag="ar_t")
                        mycanvas2.create_text(mycanvas2.winfo_screenwidth() / 2, mycanvas2.winfo_screenheight() / 1.7,
                                              text=text_arb4, anchor="center",
                                              font=("HelveticaNeueLT Arabic 45 Light", sizar, 'bold'),
                                              fill="#fff",
                                              tag="ar_t")

                        i = 1
                        j = 0
                        time.sleep(10)
                        myprogressbar.place_forget()
                        from page1 import checkinit

                        checkinit(mycanvas2, 0, root)
            except:
                screen = 0

                mycanvas2.delete("qrcode")
                mycanvas2.delete("scanbutton")
                myprogressbar.destroy()
                i = 0
                j = 0

                mycanvas2.delete("wtext")
                mycanvas2.delete("ar_text")
                # mycanvas2.delete("en_t")
                mycanvas2.delete("ar_t")
                mycanvas2.create_text(mycanvas2.winfo_screenwidth()/2,mycanvas2.winfo_screenheight()/2, text="No Service",anchor="center", font=("HelveticaNeueLT Arabic 45 Light", 26, 'bold'),
                                      fill="white",
                                      tag="status")
                from page1 import checkinit
                checkinit(mycanvas2, i, root)

                j = 0
                i = 0

        else:
            if screen==1:

                run("vcgencmd display_power 0", shell=True)
                screen=0













