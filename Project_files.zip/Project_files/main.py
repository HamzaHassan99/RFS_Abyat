

import ntpath
import time


from tkinter import  *
from tkinter import ttk
from page1 import checkinit
from connectionpage import *
#from threading import *
#import  threading
from PIL import Image, ImageTk
import  urllib.request
from io import BytesIO

import continuous_threading
from ttkbootstrap import Style




global i,entrybox
# Change threading._shutdown() to automatically call Thread.allow_shutdown()
continuous_threading.set_allow_shutdown(True)
continuous_threading.set_shutdown_timeout(0)  # Default 1
i=0

x=0
t2=None



                #Label(root, image=tkimage).pack()

def start():
    global root
    global bg,bg1

    root.title('ABYAT RFS')
    root.wm_attributes('-fullscreen','true')
    screen_width=root.winfo_screenwidth()
    screen_height=root.winfo_screenheight()
    print("%d+%d" %(screen_width, screen_height))
    root.geometry("+%d+%d" % (screen_width, screen_height))

    root.pack_propagate(False)


   # root.geometry("768x667")

    #root.resizable(width=0,height=0)

    my_canvas = Canvas(root, width=screen_width, height=screen_height,highlightthickness=0)
    my_canvas.pack(fill="both", expand=True, )


    image= Image.open("image.png")
    image=image.resize((screen_width,screen_height),Image.ANTIALIAS)
    bg=ImageTk.PhotoImage(image)
    bg1 = ImageTk.PhotoImage(file="Abyatlogo.png")



    # Set Image in canvas

    my_canvas.create_image(screen_width/2,screen_height/2, image=bg,tag="background")
    my_canvas.create_image(my_canvas.winfo_screenwidth()/2, my_canvas.winfo_screenheight()/6,image=bg1, anchor="center",tag="logo")

    # Set Text
    text1 = "Welcome to ABYAT"

    my_canvas.create_text(my_canvas.winfo_screenwidth()/2,my_canvas.winfo_screenheight()/4, text=text1,anchor="center", font=("HelveticaNeueLT Arabic 45 Light"
                                                                                                                              "", 26, 'bold'), fill="#fff",tag="wtext")


    return my_canvas

def call(x):
    s=Style()
    s.configure("green.Horizontal.TProgressbar",foreground='green',background='green')


    mcanvas=start()
    #checkinit(mcanvas,0,root)

    t2 = continuous_threading.PausableThread(target=checkinit, name='thread1', args=(
            mcanvas,0,root))


    if x == 0:
        x = 1
        t2.start()



        root.mainloop()


root=Tk()

call(0)

